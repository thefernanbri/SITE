document.addEventListener('DOMContentLoaded', function() {
  var fpassInput = document.getElementById('fpass');
  var finishCheckbox = document.getElementById('finish');
  var passwordInfo = document.getElementById('password-info');

  fpassInput.addEventListener('input', verificarSenha);

  function verificarSenha() {
    var password = fpassInput.value;
    var isSecure = isPasswordSecure(password);

    if (isSecure) {
      finishCheckbox.removeAttribute('disabled');
      passwordInfo.textContent = '';
    } else {
      finishCheckbox.setAttribute('disabled', 'disabled');
      finishCheckbox.checked = false;
      passwordInfo.textContent = 'A senha deve conter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula e um número.';
    }
  }

  function isPasswordSecure(password) {
    // Verificar se a senha possui pelo menos 8 caracteres
    if (password.length < 8) {
      return false;
    }

    // Verificar se a senha contém pelo menos uma letra maiúscula, uma letra minúscula e um número
    var uppercaseRegex = /[A-Z]/;
    var lowercaseRegex = /[a-z]/;
    var numberRegex = /[0-9]/;

    if (
      !uppercaseRegex.test(password) ||
      !lowercaseRegex.test(password) ||
      !numberRegex.test(password)
    ) {
      return false;
    }

    // Verificar se a senha atende a outros critérios de segurança, se necessário

    return true;
  }
});
