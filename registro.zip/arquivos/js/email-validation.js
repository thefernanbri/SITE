// Função para verificar se um e-mail é válido
function isValidEmail(email) {
  var emailRegex = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  return emailRegex.test(email);
}

var nextButton = document.querySelector('.c-form__next[for="progress3"]');
var cFormBorder = document.querySelector('.c-form__border');
var emailModal = document.getElementById("emailModal");

nextButton.addEventListener('click', function() {
  var emailInput = document.getElementById("femail");
  var email = emailInput.value;

  // Verificar se o e-mail é válido antes de avançar para a próxima etapa
  var isValid = isValidEmail(email);

  if (isValid) {
    cFormBorder.style.borderColor = '';
    emailModal.style.display = "none"; // Fechar a modal de e-mail se o e-mail for válido
  } else {
    cFormBorder.style.borderColor = '#ff0033';
    emailModal.style.display = "block"; // Exibir a modal de e-mail se o e-mail for inválido
    emailModal.classList.add("modal-show"); // Adicionar a classe CSS para exibir a modal no centro da tela
    event.preventDefault(); // Impedir o envio do formulário se o e-mail for inválido
  }
});

var closeBtn2 = document.querySelector(".close-email");
var emailModal = document.getElementById("emailModal");

closeBtn2.classList.add("email-close-button");

closeBtn2.addEventListener("click", function() {
  emailModal.style.display = "none"; // Fechar o modal quando o botão de fechar for clicado
});