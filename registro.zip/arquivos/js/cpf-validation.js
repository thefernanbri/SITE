// Função para verificar se um CPF é válido
function isValidCPF(cpf) {
  cpf = cpf.replace(/\D/g, '');

  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) {
    return false;
  }

  var sum = 0;
  var weight = 10;

  for (var i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i)) * weight;
    weight--;
  }

  var verificationDigit1 = 11 - (sum % 11);
  if (verificationDigit1 >= 10) {
    verificationDigit1 = 0;
  }

  sum = 0;
  weight = 11;

  for (var j = 0; j < 10; j++) {
    sum += parseInt(cpf.charAt(j)) * weight;
    weight--;
  }

  var verificationDigit2 = 11 - (sum % 11);
  if (verificationDigit2 >= 10) {
    verificationDigit2 = 0;
  }

  return (
    parseInt(cpf.charAt(9)) === verificationDigit1 &&
    parseInt(cpf.charAt(10)) === verificationDigit2
  );
}

document.querySelector('#cpf').addEventListener('keyup', function(e) {
  var cpf = e.target.value;
  cpf = cpf.replace(/\D/g, '');

  // Verificar se todos os dígitos do CPF foram digitados
  if (cpf.length === 11) {
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');

    e.target.value = cpf;

    // Verificar se o CPF é válido antes de avançar para a próxima etapa
    var isValid = isValidCPF(cpf);
    var nextButton = document.querySelector('.c-form__next[for="progress2"]');
    var cFormBorder = document.querySelector('.c-form__border');

    if (isValid) {
      nextButton.style.pointerEvents = 'initial';
      nextButton.style.color = '#25a3ff';
      cFormBorder.style.borderColor = '';
      var modal = document.getElementById("modal");
      modal.style.display = "none"; // Fechar o modal se o CPF for válido
    } else {
      nextButton.style.pointerEvents = 'none';
      nextButton.style.color = '#ff0033';
      var modal = document.getElementById("modal");
      modal.style.display = "block"; // Exibir o modal se o CPF for inválido
      modal.classList.add("modal-show"); // Adicionar a classe CSS para exibir o modal no centro da tela
    }
  } else {
    var nextButton = document.querySelector('.c-form__next[for="progress2"]');
    nextButton.style.pointerEvents = 'none';
    nextButton.style.color = '#ff0033';
    var cFormBorder = document.querySelector('.c-form__border');
    cFormBorder.style.borderColor = '';
    var modal = document.getElementById("modal");
    modal.style.display = "none"; // Fechar o modal se não todos os dígitos foram digitados
  }
});

var closeBtn = document.querySelector(".close");
var modal = document.getElementById("modal");

closeBtn.addEventListener("click", function() {
  modal.style.display = "none"; // Fechar o modal quando o botão de fechar for clicado
});
