function validarCPF(cpf) {
  cpf = cpf.replace(/\D/g, '');

  // Verifica o tamanho do CPF
  if (cpf.length !== 11) {
    return false;
  }

  // Verifica se todos os dígitos são iguais
  for (var i = 0; i < 10; i++) {
    if (cpf.charAt(i) !== cpf.charAt(i + 1)) {
      break;
    }
  }
  if (i === 10) {
    return false;
  }

  // Calcula o primeiro dígito verificador
  var soma = 0;
  for (var i = 0; i < 9; i++) {
    soma += parseInt(cpf.charAt(i)) * (10 - i);
  }
  var resto = soma % 11;
  var digitoVerificador1 = resto < 2 ? 0 : 11 - resto;

  // Verifica o primeiro dígito verificador
  if (digitoVerificador1 !== parseInt(cpf.charAt(9))) {
    return false;
  }

  // Calcula o segundo dígito verificador
  soma = 0;
  for (var i = 0; i < 10; i++) {
    soma += parseInt(cpf.charAt(i)) * (11 - i);
  }
  resto = soma % 11;
  var digitoVerificador2 = resto < 2 ? 0 : 11 - resto;

  // Verifica o segundo dígito verificador
  if (digitoVerificador2 !== parseInt(cpf.charAt(10))) {
    return false;
  }

  return true;
}

var typingTimer;
var doneTypingInterval = 200;

document.addEventListener('DOMContentLoaded', function() {
  var cpfInput = document.querySelector('#cpf');
  var errorElement = document.querySelector('#cpf-error');
  var errosElement = document.querySelector('.erros');
  var submitButton = document.querySelector('.submit');

  errosElement.style.display = 'none';

  cpfInput.addEventListener('input', function(e) {
    var input = e.target;
    var cpf = input.value;

    clearTimeout(typingTimer);

    if (cpf.length === 14) {
      var isValid = validarCPF(cpf);
      if (isValid) {
        input.setCustomValidity('');
        errorElement.textContent = '';
        errosElement.style.display = 'none';
        submitButton.disabled = false; // Habilita o botão de submit
      } else {
        input.setCustomValidity('CPF inválido');
        errorElement.textContent = 'CPF inválido';
        errosElement.style.display = 'block';
        submitButton.disabled = true; // Desabilita o botão de submit
      }
    } else {
      input.setCustomValidity('');
      errorElement.textContent = '';
      errosElement.style.display = 'none';
      submitButton.disabled = false; // Habilita o botão de submit
    }
  });

  cpfInput.addEventListener('keydown', function() {
    clearTimeout(typingTimer);
  });

  cpfInput.addEventListener('keyup', function() {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(function() {
      var input = document.querySelector('#cpf');
      var cpf = input.value;

      if (cpf.length === 14) {
        var isValid = validarCPF(cpf);
        if (isValid) {
          input.setCustomValidity('');
          errorElement.textContent = '';
          errosElement.style.display = 'none';
          submitButton.disabled = false; // Habilita o botão de submit
        } else {
          input.setCustomValidity('CPF inválido');
          errorElement.textContent = 'CPF inválido';
          errosElement.style.display = 'block';
          submitButton.disabled = true; // Desabilita o botão de submit
        }
      } else {
        input.setCustomValidity('');
        errorElement.textContent = '';
        errosElement.style.display = 'none';
        submitButton.disabled = false; // Habilita o botão de submit
      }
    }, doneTypingInterval);
  });
});